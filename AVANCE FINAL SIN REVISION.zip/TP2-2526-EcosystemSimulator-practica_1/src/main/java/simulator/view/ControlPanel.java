package simulator.view; 

import java.awt.BorderLayout;
import java.io.File;
import java.nio.file.Files;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import org.json.JSONObject;

import simulator.control.Controller;

class ControlPanel extends JPanel {

	private Controller ctrl;
	private ChangeRegionsDialog changeRegionsDialog;

	private JToolBar toolBar;
	private JFileChooser fc;
	private boolean stopped = true;

	private JButton openButton;
	private JButton mapButton;
	private JButton regionsButton;
	private JButton runButton;
	private JButton stopButton;
	private JButton quitButton;
	private JSpinner stepsSpinner;
	private JTextField dtField;

	ControlPanel(Controller ctrl) {
		this.ctrl = ctrl;
		initGUI();
	}

	private void initGUI() {
		setLayout(new BorderLayout());
		toolBar = new JToolBar();
		add(toolBar, BorderLayout.PAGE_START);

		this.fc = new JFileChooser();
		this.fc.setCurrentDirectory(new File(System.getProperty("user.dir") + "/resources/examples"));

		this.changeRegionsDialog = new ChangeRegionsDialog(this.ctrl);

		// 1. Botón Open
		this.openButton = new JButton();
		this.openButton.setToolTipText("Load a file");
		this.openButton.setIcon(new ImageIcon("src/main/resources/icons/open.png"));
		this.openButton.addActionListener(e -> loadFile());
		this.toolBar.add(this.openButton);

		this.toolBar.addSeparator();

		// 2. Botón MapWindow
		this.mapButton = new JButton();
		this.mapButton.setToolTipText("Open Map Window");
		this.mapButton.setIcon(new ImageIcon("src/main/resources/icons/viewer.png"));
		this.mapButton.addActionListener(e -> new MapWindow(ViewUtils.getWindow(this), ctrl)); 
		this.toolBar.add(this.mapButton);

		// 3. Botón Change Regions
		this.regionsButton = new JButton();
		this.regionsButton.setToolTipText("Change Regions");
		this.regionsButton.setIcon(new ImageIcon("src/main/resources/icons/regions.png"));
		this.regionsButton.addActionListener(e -> this.changeRegionsDialog.open(ViewUtils.getWindow(this)));
		this.toolBar.add(this.regionsButton);

		this.toolBar.addSeparator();

		// 4. Botón Run
		this.runButton = new JButton();
		this.runButton.setToolTipText("Run Simulation");
		this.runButton.setIcon(new ImageIcon("src/main/resources/icons/run.png"));
		this.runButton.addActionListener(e -> {
			setButtonsEnabled(false);
			this.stopped = false;
			int n = (Integer) this.stepsSpinner.getValue();
			double dt = Double.parseDouble(this.dtField.getText());
			runSim(n, dt);
		});
		this.toolBar.add(this.runButton);

		// 5. Botón Stop
		this.stopButton = new JButton();
		this.stopButton.setToolTipText("Stop Simulation");
		this.stopButton.setIcon(new ImageIcon("src/main/resources/icons/stop.png"));
		this.stopButton.addActionListener(e -> this.stopped = true);
		this.toolBar.add(this.stopButton);

		// 6. Componentes de Steps y Delta-Time
		this.toolBar.add(new JLabel(" Steps: "));
		this.stepsSpinner = new JSpinner(new SpinnerNumberModel(10000, 1, 100000, 100));
		this.stepsSpinner.setMaximumSize(this.stepsSpinner.getPreferredSize());
		this.toolBar.add(this.stepsSpinner);

		this.toolBar.add(new JLabel(" Delta-Time: "));
		this.dtField = new JTextField("0.03", 5);
		this.dtField.setMaximumSize(this.dtField.getPreferredSize());
		this.toolBar.add(this.dtField);

		// 7. Quit Button
		this.toolBar.add(Box.createGlue());
		this.toolBar.addSeparator();
		this.quitButton = new JButton();
		this.quitButton.setToolTipText("Quit");
		this.quitButton.setIcon(new ImageIcon("src/main/resources/icons/exit.png"));
		this.quitButton.addActionListener((e) -> ViewUtils.quit(this));
		this.toolBar.add(this.quitButton);
	}

	private void loadFile() {
		int ret = this.fc.showOpenDialog(ViewUtils.getWindow(this));
		if (ret == JFileChooser.APPROVE_OPTION) {
			try {
				File file = this.fc.getSelectedFile();
				String content = new String(Files.readAllBytes(file.toPath()));
				JSONObject jsonStr = new JSONObject(content);

				int cols = jsonStr.getInt("cols");
				int rows = jsonStr.getInt("rows");
				int width = jsonStr.getInt("width");
				int height = jsonStr.getInt("height");

				this.ctrl.reset(cols, rows, width, height);
				this.ctrl.loadData(jsonStr);
			} catch (Exception e) {
				ViewUtils.showErrorMsg(e.getMessage());
			}
		}
	}

	private void runSim(int n, double dt) {
		if (n > 0 && !this.stopped) {
			try {
				this.ctrl.advance(dt);
				SwingUtilities.invokeLater(() -> runSim(n - 1, dt));
			} catch (Exception e) {
				ViewUtils.showErrorMsg(e.getMessage());
				setButtonsEnabled(true);
				this.stopped = true;
			}
		} else {
			setButtonsEnabled(true);
			this.stopped = true;
		}
	}

	private void setButtonsEnabled(boolean enabled) {
		this.openButton.setEnabled(enabled);
		this.mapButton.setEnabled(enabled);
		this.regionsButton.setEnabled(enabled);
		this.runButton.setEnabled(enabled);
		// Stop button siempre debe estar disponible para parar, el Quit también
	}
}