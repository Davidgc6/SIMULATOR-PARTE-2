package simulator.control;

import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.model.Simulator;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.view.SimpleObjectViewer;
import simulator.view.SimpleObjectViewer.ObjInfo;

public class Controller {
	
	private Simulator sim;
	
	public Controller(Simulator sim) {
		this.sim = sim;
	}

	private List<ObjInfo> toAnimalsInfo(List<? extends AnimalInfo> animals) {
		List<ObjInfo> ol = new ArrayList<>(animals.size());
		for (AnimalInfo a : animals) {
			int size = (int) Math.round(a.getAge())	+ 2;
			ol.add(new ObjInfo(a.getGeneticCode(), (int) a.getPosition().getX(), (int) a.getPosition().getY(), size));
		}
		return ol;
	}
	
	public void loadData(JSONObject data) {
		if (data.has("regions")) {
			JSONArray regionsArray = data.getJSONArray("regions");
			for (int i = 0; i < regionsArray.length(); i++) {
				JSONObject rObj = regionsArray.getJSONObject(i);
				JSONArray rowArray = rObj.getJSONArray("row");
				JSONArray colArray = rObj.getJSONArray("col");
				JSONObject spec = rObj.getJSONObject("spec");
				
				int rFrom = rowArray.getInt(0);
				int rTo = rowArray.length() > 1 ? rowArray.getInt(1) : rFrom;
				int cFrom = colArray.getInt(0);
				int cTo = colArray.length() > 1 ? colArray.getInt(1) : cFrom;
				
				for (int r = rFrom; r <= rTo; r++) {
					for (int c = cFrom; c <= cTo; c++) {
						sim.setRegion(r, c, spec);
					}
				}
			}
		}
		
		if (data.has("animals")) {
			JSONArray animalArray = data.getJSONArray("animals");
			for (int i = 0; i < animalArray.length(); i++) {
				JSONObject aObj = animalArray.getJSONObject(i);
				int amount = aObj.getInt("amount");
				JSONObject spec = aObj.getJSONObject("spec");
				for (int j = 0; j < amount; j++) {
					sim.addAnimal(spec); 
				}
			}
		}
	}
	
	public void run(double t, double dt, boolean sv, OutputStream out) {
		JSONObject initcontrollerJSON = sim.asJSON();
		
		SimpleObjectViewer view = null;
		
		if (sv) {
			MapInfo m = sim.getMapInfo();
			view = new SimpleObjectViewer("[ECOSYSTEM]", m.getWidth(), m.getHeight(), m.getCols(), m.getRows());
			view.update(toAnimalsInfo(sim.getAnimals()), sim.getTime(), dt);
		}
		
		while (sim.getTime() <= t) {
			sim.advance(dt);
			if (sv) {
				view.update(toAnimalsInfo(sim.getAnimals()), sim.getTime(), dt);
			}
		}
		
		JSONObject finalcontrollerJSON = sim.asJSON();
		
		JSONObject outputJSON = new JSONObject();
		outputJSON.put("in", initcontrollerJSON);
		outputJSON.put("out", finalcontrollerJSON);
		
		PrintStream p = new PrintStream(out);
		p.println(outputJSON.toString(3));
		
		if (sv) {
			view.close();
		}
	}
}