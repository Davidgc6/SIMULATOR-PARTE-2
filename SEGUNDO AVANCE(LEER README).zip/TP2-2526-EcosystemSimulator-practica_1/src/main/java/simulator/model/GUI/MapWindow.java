package simulator.model.GUI;

import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JPanel;

import simulator.control.Controller;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;
import simulator.view.AbstractMapViewer;

class MapWindow extends JFrame implements EcoSysObserver {

	  private Controller ctrl;
	  private AbstractMapViewer viewer;
	  private Frame parent;

	  MapWindow(Frame parent, Controller ctrl2) {
	    super("[MAP VIEWER]");
	    this.ctrl = ctrl2;
	    this.parent = parent;
	    intiGUI();
	    // TODO registrar this como observador
	  }

	  private void intiGUI() {
	    JPanel mainPanel = new JPanel(new BorderLayout());
	    // TODO poner contentPane como mainPanel

	    // TODO crear el viewer y añadirlo a mainPanel (en el centro)

	    // TODO en el método windowClosing, eliminar ‘MapWindow.this’ de los
	    //      observadores
	    addWindowListener(new WindowListener() {

			@Override
			public void windowOpened(WindowEvent e) {}

			@Override
			public void windowClosing(WindowEvent e) {
				remove(MapWindow.this);
			}

			@Override
			public void windowClosed(WindowEvent e) {}

			@Override
			public void windowIconified(WindowEvent e) {}

			@Override
			public void windowDeiconified(WindowEvent e) {}

			@Override
			public void windowActivated(WindowEvent e) {}

			@Override
			public void windowDeactivated(WindowEvent e) {} 
			});

	    pack();
	    if (this.parent != null)
	      setLocation(
	        this.parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
	        this.parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
	      setResizable(false);
	      setVisible(true);
	  }

	  @Override
	  public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// TODO Auto-generated method stub
		
	  }

	  @Override
	  public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// TODO Auto-generated method stub
		
	  }
	}
