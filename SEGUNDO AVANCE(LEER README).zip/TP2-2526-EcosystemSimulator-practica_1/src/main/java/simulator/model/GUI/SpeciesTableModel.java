package simulator.model.GUI;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.misc.State;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

public class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver {

	private Controller ctrl;
	private List<String> speciesList;
	private Map<String, Map<State, Integer>> speciesData;
	private String[] columnNames;
	
	SpeciesTableModel(Controller ctrl) {
		this.ctrl = ctrl;
		
		// Inicializar estructuras de datos
		this.speciesList = new ArrayList<>();
		this.speciesData = new HashMap<>();

		State[] states = State.values();
		this.columnNames = new String[states.length + 1];
		this.columnNames[0] = "Species";
		for (int i = 0; i < states.length; i++) {
			this.columnNames[i + 1] = states[i].name();
		}

		// Registrar this como observador
		this.ctrl.addObserver(this);
	}
	
	
	@Override
	public int getRowCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getColumnCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// TODO Auto-generated method stub

	}
	



}
