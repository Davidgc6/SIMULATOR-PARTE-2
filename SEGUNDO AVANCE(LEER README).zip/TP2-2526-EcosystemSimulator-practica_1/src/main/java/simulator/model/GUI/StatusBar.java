package simulator.model.GUI;

import java.awt.FlowLayout;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JPanel;

import simulator.control.Controller;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

public class StatusBar extends JPanel implements EcoSysObserver {
	
	// TODO Añadir los atributos necesarios.
	
	StatusBar(Controller ctrl) {
	    initGUI();
	    // TODO registrar this como observador
	  }

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// TODO Auto-generated method stub

	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// TODO Auto-generated method stub

	}

	  

	  private void initGUI() {
	    this.setLayout(new FlowLayout(FlowLayout.LEFT));
	    this.setBorder(BorderFactory.createBevelBorder(1));

	    // TODO Crear varios JLabel para el tiempo, el número de animales, y la
	    //      dimensión y añadirlos al panel. Puedes utilizar el siguiente código
	    //      para añadir un separador vertical:
	    //
	    //     JSeparator s = new JSeparator(JSeparator.VERTICAL);
	    //     s.setPreferredSize(new Dimension(10, 20));
	    //     this.add(s);
	  }

	
}
