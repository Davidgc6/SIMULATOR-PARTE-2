package simulator.model.regions;

import simulator.misc.Diet;
import simulator.misc.Utils;
import simulator.model.animals.AnimalInfo;

public class DynamicSupplyRegion extends Region {

	private double food;
	private double factor;

	public DynamicSupplyRegion(double initialFood, double growthFactor) {
		super();
		this.food = initialFood;
		this.factor = growthFactor;
	}

	@Override
	public double getfood(AnimalInfo a, double dt) {
		if (a.getDiet() == Diet.CARNIVORE) {
			return 0.0;
		}
		
		int n = herbivoresInRegion();
		
		double wantedFood = 60.0 * Math.exp(-Math.max(0, n - 5.0) * 2.0) * dt;
		
		double actualFood = Math.min(this.food, wantedFood);
		
		this.food -= actualFood;
		
		return actualFood;
	}

	@Override
	public void update(double dt) {
		if (Utils.RAND.nextDouble() < 0.5) {
			this.food += dt * this.factor;
		}
	}
	
	@Override
	public String toString() {
		return "Dynamic region"; // O "Dynamic food supply"
	}
}