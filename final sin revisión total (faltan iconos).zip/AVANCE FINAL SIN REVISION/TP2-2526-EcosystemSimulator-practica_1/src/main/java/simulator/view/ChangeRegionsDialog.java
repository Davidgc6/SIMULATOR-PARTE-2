package simulator.view;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.launcher.Main;
import simulator.control.Controller;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

class ChangeRegionsDialog extends JDialog implements EcoSysObserver {

	private DefaultComboBoxModel<String> regionsModel;
	private DefaultComboBoxModel<String> fromRowModel;
	private DefaultComboBoxModel<String> toRowModel;
	private DefaultComboBoxModel<String> fromColModel;
	private DefaultComboBoxModel<String> toColModel;

	private DefaultTableModel dataTableModel;
	private Controller ctrl;
	private List<JSONObject> regionsInfo;

	private String[] headers = { "Key", "Value", "Description" };

	// Atributos añadidos
	private int status;
	private JComboBox<String> regionsCB;
	private JTable dataTable;

	ChangeRegionsDialog(Controller ctrl) {
		super((Frame) null, true);
		this.ctrl = ctrl;
		initGUI();
		// Registrar this como observer
		this.ctrl.addObserver(this);
	}

	private void initGUI() {
		setTitle("Change Regions");
		JPanel mainPanel = new JPanel();
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		setContentPane(mainPanel);

		// 1. Panel de ayuda
		JPanel helpPanel = new JPanel(new BorderLayout());
		JLabel helpLabel = new JLabel("<html><body><p style='margin:10px;'>Seleccione un tipo de región, el rango de filas y columnas, "
				+ "y proporcione los valores deseados para los parámetros de la región en la tabla inferior.</p></body></html>");
		helpPanel.add(helpLabel, BorderLayout.CENTER);
		mainPanel.add(helpPanel);

		// Obtener info de las regiones
		this.regionsInfo = Main.regionFactory.getInfo();

		// 2. Modelo de la tabla
		this.dataTableModel = new DefaultTableModel() {
			@Override
			public boolean isCellEditable(int row, int column) {
				// Hacemos editable SOLO la columna 1 ("Value")
				return column == 1;
			}
		};
		this.dataTableModel.setColumnIdentifiers(this.headers);

		// 3. Panel de la Tabla
		JPanel tablePanel = new JPanel(new BorderLayout());
		this.dataTable = new JTable(this.dataTableModel);
		JScrollPane scrollPane = new JScrollPane(this.dataTable);
		tablePanel.add(scrollPane, BorderLayout.CENTER);
		mainPanel.add(tablePanel);

		// 4. Panel de ComboBoxes (Regiones y Coordenadas)
		JPanel combosPanel = new JPanel();
		combosPanel.setLayout(new BoxLayout(combosPanel, BoxLayout.Y_AXIS));

		// --- Panel interior para el Tipo de Región ---
		JPanel regionTypePanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		this.regionsModel = new DefaultComboBoxModel<>();
		// Añadir descripción de todas las regiones
		for (JSONObject info : regionsInfo) {
			if (info.has("desc")) {
				regionsModel.addElement(info.getString("desc"));
			} else {
				regionsModel.addElement(info.getString("type"));
			}
		}
		this.regionsCB = new JComboBox<>(this.regionsModel);
		// Listener para actualizar la tabla al cambiar de región
		this.regionsCB.addActionListener((e) -> updateTableModel(regionsCB.getSelectedIndex()));
		regionTypePanel.add(new JLabel("Region Type:"));
		regionTypePanel.add(this.regionsCB);
		combosPanel.add(regionTypePanel);

		// --- Panel interior para las Coordenadas ---
		JPanel coordsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		this.fromRowModel = new DefaultComboBoxModel<>();
		this.toRowModel = new DefaultComboBoxModel<>();
		this.fromColModel = new DefaultComboBoxModel<>();
		this.toColModel = new DefaultComboBoxModel<>();

		JComboBox<String> fromRowCB = new JComboBox<>(fromRowModel);
		JComboBox<String> toRowCB = new JComboBox<>(toRowModel);
		JComboBox<String> fromColCB = new JComboBox<>(fromColModel);
		JComboBox<String> toColCB = new JComboBox<>(toColModel);

		coordsPanel.add(new JLabel("Row from/to:"));
		coordsPanel.add(fromRowCB);
		coordsPanel.add(toRowCB);
		coordsPanel.add(new JLabel("Col from/to:"));
		coordsPanel.add(fromColCB);
		coordsPanel.add(toColCB);
		combosPanel.add(coordsPanel);

		mainPanel.add(combosPanel);

		// 5. Panel de Botones
		JPanel buttonsPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		JButton okButton = new JButton("OK");
		JButton cancelButton = new JButton("Cancel");

		// Lógica del botón Cancel
		cancelButton.addActionListener(e -> {
			this.status = 0;
			setVisible(false);
		});

		// Lógica del botón OK
		okButton.addActionListener(e -> handleOKAction());

		buttonsPanel.add(cancelButton);
		buttonsPanel.add(okButton);
		mainPanel.add(buttonsPanel);

		// Actualizar tabla inicialmente con el primer elemento si existe
		if (regionsModel.getSize() > 0) {
			regionsCB.setSelectedIndex(0);
		}

		setPreferredSize(new Dimension(700, 400));
		pack();
		setResizable(false);
		setVisible(false);
	}

	private void updateTableModel(int index) {
		// Limpiar la tabla
		dataTableModel.setRowCount(0);
		
		if (index >= 0 && index < regionsInfo.size()) {
			JSONObject info = regionsInfo.get(index);
			if (info.has("data")) {
				JSONObject data = info.getJSONObject("data");
				for (String key : data.keySet()) {
					String desc = data.getString(key);
					// Añadimos fila: {Clave, Valor (vacío por defecto), Descripción}
					dataTableModel.addRow(new Object[] { key, "", desc });
				}
			}
		}
	}

	private void handleOKAction() {
		try {
			// Si la tabla se está editando, paramos la edición para guardar el valor
			if (dataTable.isEditing()) {
				dataTable.getCellEditor().stopCellEditing();
			}

			// i. Convertir la información de la tabla en un JSON (region_data)
			JSONObject region_data = new JSONObject();
			for (int i = 0; i < dataTableModel.getRowCount(); i++) {
				String key = (String) dataTableModel.getValueAt(i, 0);
				String value = (String) dataTableModel.getValueAt(i, 1);
				// Solo añadimos si el valor no está vacío
				if (value != null && !value.trim().isEmpty()) {
					region_data.put(key, value);
				}
			}

			// ii. Sacar el tipo de región seleccionada
			int selectedIndex = regionsCB.getSelectedIndex();
			JSONObject info = regionsInfo.get(selectedIndex);
			String region_type = info.getString("type");

			// iii. Sacar las coordenadas de los combobox
			int row_from = Integer.parseInt((String) fromRowModel.getSelectedItem());
			int row_to = Integer.parseInt((String) toRowModel.getSelectedItem());
			int col_from = Integer.parseInt((String) fromColModel.getSelectedItem());
			int col_to = Integer.parseInt((String) toColModel.getSelectedItem());

			// iv. Crear JSON con el formato pedido
			JSONObject finalJson = new JSONObject();
			JSONArray regionsArray = new JSONArray();
			
			JSONObject regionObj = new JSONObject();
			
			JSONArray rowArray = new JSONArray();
			rowArray.put(row_from);
			rowArray.put(row_to);
			
			JSONArray colArray = new JSONArray();
			colArray.put(col_from);
			colArray.put(col_to);
			
			JSONObject specObj = new JSONObject();
			specObj.put("type", region_type);
			specObj.put("data", region_data);

			regionObj.put("row", rowArray);
			regionObj.put("col", colArray);
			regionObj.put("spec", specObj);
			
			regionsArray.put(regionObj);
			finalJson.put("regions", regionsArray);

			// Pasar el JSON al controlador
			this.ctrl.setRegions(finalJson);

			// Éxito: estado 1 e invisible
			this.status = 1;
			setVisible(false);

		} catch (Exception ex) {
			// Mostrar error con ViewUtils y no con System.out o stackTrace
			ViewUtils.showErrorMsg(ex.getMessage());
		}
	}

	public void open(Frame parent) {
		setLocation(
			parent.getLocation().x + parent.getWidth() / 2 - getWidth() / 2,
			parent.getLocation().y + parent.getHeight() / 2 - getHeight() / 2);
		pack();
		setVisible(true);
	}

	// Método auxiliar para actualizar los combos
	private void updateCoordsModels(int cols, int rows) {
		fromRowModel.removeAllElements();
		toRowModel.removeAllElements();
		fromColModel.removeAllElements();
		toColModel.removeAllElements();

		for (int i = 0; i < rows; i++) {
			fromRowModel.addElement(String.valueOf(i));
			toRowModel.addElement(String.valueOf(i));
		}
		for (int i = 0; i < cols; i++) {
			fromColModel.addElement(String.valueOf(i));
			toColModel.addElement(String.valueOf(i));
		}
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		updateCoordsModels(map.getCols(), map.getRows());
	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		updateCoordsModels(map.getCols(), map.getRows());
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		// No hace falta actualizar nada aquí para este diálogo
	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// No hace falta actualizar nada aquí para este diálogo
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		// No hace falta actualizar nada aquí para este diálogo
	}

}