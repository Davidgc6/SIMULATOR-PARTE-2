package simulator.view;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.TableModel;

public class InfoTable extends JPanel {

	private String title;
	private TableModel tableModel;

	public InfoTable(String title, TableModel tableModel) {
		this.title = title;
		this.tableModel = tableModel;
		initGUI();
	}

	private void initGUI() {
		// 1. Cambiar el layout a BorderLayout
		this.setLayout(new BorderLayout());
		
		// 2. Añadir un borde con título
		this.setBorder(BorderFactory.createTitledBorder(this.title));
		
		// 3. Añadir JTable con scroll vertical
		JTable table = new JTable(this.tableModel);
		this.add(new JScrollPane(table), BorderLayout.CENTER);
	}
}