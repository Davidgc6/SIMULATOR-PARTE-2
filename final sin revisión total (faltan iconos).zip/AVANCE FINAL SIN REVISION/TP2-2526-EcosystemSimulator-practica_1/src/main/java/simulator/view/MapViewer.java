package simulator.view;

import simulator.model.animals.AnimalInfo;
import simulator.misc.State;
import simulator.model.MapInfo;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Rectangle2D;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

@SuppressWarnings("serial")
public class MapViewer extends AbstractMapViewer {

	private int width;
	private int height;
	private int rows;
	private int cols;
	int rWidth;
	int rHeight;

	State currentState;
	volatile private Collection<AnimalInfo> objs;
	volatile private Double time;

	private static class SpeciesInfo {
		private Integer count;
		private Color color;

		SpeciesInfo(Color color) {
			count = 0;
			this.color = color;
		}
	}

	Map<String, SpeciesInfo> kindsInfo = new HashMap<>();
	private Font textFont = new Font("Arial", Font.BOLD, 12);
	private boolean showHelp;

	public MapViewer() {
		initGUI();
	}

	private void initGUI() {

		addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				switch (e.getKeyChar()) {
				case 'h':
					showHelp = !showHelp;
					repaint();
					break;
				case 's':
					// Cambiar currState al siguiente (de manera circular).
					State[] states = State.values();
					if (currentState == null) {
						currentState = states[0]; // Del nulo pasa al primero
					} else {
						int i = 0;
						while (i < states.length && states[i] != currentState) {
							i++;
						}
						// Si era el último, vuelve a null. Si no, pasa al siguiente.
						if (i == states.length - 1) {
							currentState = null;
						} else {
							currentState = states[i + 1];
						}
					}
					repaint();
					break;
				default:
				}
			}
		});

		addMouseListener(new MouseAdapter() {
			@Override
			public void mouseEntered(MouseEvent e) {
				requestFocus();
			}
		});

		currentState = null;
		showHelp = true;
	}

	@Override
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);

		Graphics2D gr = (Graphics2D) g;
		gr.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		gr.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

		g.setFont(textFont);
		gr.setBackground(Color.WHITE);
		gr.clearRect(0, 0, width, height);

		if (objs != null)
			drawObjects(gr, objs, time);

		// Mostrar el texto de ayuda en dos líneas si showHelp es true
		if (showHelp) {
			gr.setColor(Color.RED);
			drawStringWithRect(gr, 10, 20, "h: toggle help");
			drawStringWithRect(gr, 10, 40, "s: show animals of a specific state");
		}
	}

	private boolean visible(AnimalInfo a) {
		// Visible si currState es null (todos) o coincide exactamente
		return currentState == null || a.getState() == currentState;
	}

	private void drawObjects(Graphics2D g, Collection<AnimalInfo> animals, Double time) {

		// 1. Dibujar el grid de regiones.
		g.setColor(Color.LIGHT_GRAY);
		for (int r = 0; r <= rows; r++) {
			g.drawLine(0, r * rHeight, cols * rWidth, r * rHeight); // Líneas horizontales
		}
		for (int c = 0; c <= cols; c++) {
			g.drawLine(c * rWidth, 0, c * rWidth, rows * rHeight);  // Líneas verticales
		}

		// 2. Dibujar los animales.
		for (AnimalInfo a : animals) {
			if (!visible(a))
				continue;

			String geneticCode = a.getGeneticCode();
			SpeciesInfo speciesInfo = kindsInfo.get(geneticCode);

			// Si es null, lo registramos en el mapa
			if (speciesInfo == null) {
				speciesInfo = new SpeciesInfo(ViewUtils.getColor(geneticCode));
				kindsInfo.put(geneticCode, speciesInfo);
			}

			speciesInfo.count++; // Incrementamos el contador

			// Dibujamos el círculo (sujeto a su edad)
			g.setColor(speciesInfo.color);
			int size = (int) (a.getAge() / 2.0 + 2.0);
			int x = (int) a.getPosition().getX() - size / 2;
			int y = (int) a.getPosition().getY() - size / 2;
			g.fillOval(x, y, size, size);
		}

		// --- Textos de información en la parte inferior ---
		int textY = height - 15;
		int textX = 10;

		// 3. Dibujar la etiqueta del tiempo (3 decimales)
		g.setColor(Color.MAGENTA);
		String timeText = String.format("Time: %.3f", time);
		drawStringWithRect(g, textX, textY, timeText);
		textX += g.getFontMetrics().stringWidth(timeText) + 20;

		// 4. Dibujar la etiqueta del estado visible
		if (currentState != null) {
			g.setColor(Color.BLUE);
			String stateText = "State: " + currentState.toString();
			drawStringWithRect(g, textX, textY, stateText);
			textX += g.getFontMetrics().stringWidth(stateText) + 20;
		}

		// 5. Dibujar la información de todas las especies y resetear contadores
		for (Entry<String, SpeciesInfo> e : kindsInfo.entrySet()) {
			g.setColor(e.getValue().color);
			String speciesText = e.getKey() + ": " + e.getValue().count;
			drawStringWithRect(g, textX, textY, speciesText);
			textX += g.getFontMetrics().stringWidth(speciesText) + 20; // Separación dinámica

			e.getValue().count = 0; // Reset a 0 para el siguiente tick
		}
	}

	void drawStringWithRect(Graphics2D g, int x, int y, String s) {
		Rectangle2D rect = g.getFontMetrics().getStringBounds(s, g);
		g.drawString(s, x, y);
		g.drawRect(x - 1, y - (int) rect.getHeight(), (int) rect.getWidth() + 1, (int) rect.getHeight() + 5);
	}

	@Override
	public void update(List<AnimalInfo> objs, Double time) {
		this.objs = objs;
		this.time = time;
		repaint(); // Obligamos a repintar el componente
	}

	@Override
	public void reset(double time, MapInfo map, List<AnimalInfo> animals) {
		// Actualizar las métricas físicas del terreno
		this.width = map.getWidth();
		this.height = map.getHeight();
		this.cols = map.getCols();
		this.rows = map.getRows();
		this.rWidth = map.getRegionWidth();
		this.rHeight = map.getRegionHeight();

		// Redimensionar el componente internamente
		setPreferredSize(new Dimension(this.width, this.height));
		
		update(animals, time);
	}
}