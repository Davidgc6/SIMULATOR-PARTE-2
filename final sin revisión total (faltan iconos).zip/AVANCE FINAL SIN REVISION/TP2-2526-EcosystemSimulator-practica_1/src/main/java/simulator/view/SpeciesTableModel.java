package simulator.view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.misc.State;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

public class SpeciesTableModel extends AbstractTableModel implements EcoSysObserver {

	private List<String> columnNames;
	private List<String> speciesList; // Fila: Código genético
	private Map<String, Map<State, Integer>> data; // Matriz de conteo

	public SpeciesTableModel(Controller ctrl) {
		this.columnNames = new ArrayList<>();
		this.speciesList = new ArrayList<>();
		this.data = new HashMap<>();
		
		// Columnas dinámicas
		this.columnNames.add("Species");
		for (State s : State.values()) {
			this.columnNames.add(s.toString());
		}
		
		ctrl.addObserver(this);
	}

	@Override
	public int getRowCount() {
		return speciesList.size();
	}

	@Override
	public int getColumnCount() {
		return columnNames.size();
	}

	@Override
	public String getColumnName(int column) {
		return columnNames.get(column);
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		String species = speciesList.get(rowIndex);
		if (columnIndex == 0) {
			return species;
		}
		State state = State.values()[columnIndex - 1];
		return data.get(species).getOrDefault(state, 0);
	}

	private void updateData(List<AnimalInfo> animals) {
		data.clear();
		speciesList.clear();
		
		for (AnimalInfo a : animals) {
			String geneticCode = a.getGeneticCode(); // Corregido
			data.putIfAbsent(geneticCode, new HashMap<>());
			
			Map<State, Integer> stateCount = data.get(geneticCode);
			State animalState = a.getState(); // Corregido
			stateCount.put(animalState, stateCount.getOrDefault(animalState, 0) + 1);
		}
		
		speciesList.addAll(data.keySet());
		fireTableDataChanged(); // Avisamos a Swing de que repinte la tabla
	}

	@Override public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) { updateData(animals); }
	@Override public void onReset(double time, MapInfo map, List<AnimalInfo> animals) { updateData(animals); }
	@Override public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) { updateData(animals); }
	@Override public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) { updateData(animals); }
	@Override public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) { }
}