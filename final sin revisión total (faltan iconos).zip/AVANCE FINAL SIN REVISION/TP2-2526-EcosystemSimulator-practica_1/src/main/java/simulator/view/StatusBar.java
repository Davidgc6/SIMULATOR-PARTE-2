package simulator.view; // Asegúrate de que el paquete es el correcto

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.SwingUtilities;

import simulator.control.Controller;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

public class StatusBar extends JPanel implements EcoSysObserver {

	private JLabel timeLabel;
	private JLabel totalAnimalsLabel;
	private JLabel dimensionLabel;

	StatusBar(Controller ctrl) {
		initGUI();
		// Registrar this como observador del controlador
		ctrl.addObserver(this);
	}

	private void initGUI() {
		this.setLayout(new FlowLayout(FlowLayout.LEFT));
		this.setBorder(BorderFactory.createBevelBorder(1));

		// Inicializamos los JLabels
		timeLabel = new JLabel("Time: 0.000");
		totalAnimalsLabel = new JLabel("Total Animals: 0");
		dimensionLabel = new JLabel("Dimension: 0x0 (0x0)");

		// Añadimos tiempo y separador
		this.add(timeLabel);
		this.add(createSeparator());

		// Añadimos total de animales y separador
		this.add(totalAnimalsLabel);
		this.add(createSeparator());

		// Añadimos dimensiones
		this.add(dimensionLabel);
	}

	// Método auxiliar para no repetir código creando separadores
	private JSeparator createSeparator() {
		JSeparator s = new JSeparator(JSeparator.VERTICAL);
		s.setPreferredSize(new Dimension(10, 20));
		return s;
	}

	// Método auxiliar para actualizar la interfaz gráficamente de forma segura
	private void updateInfo(double time, MapInfo map, int totalAnimals) {
		SwingUtilities.invokeLater(() -> {
			timeLabel.setText(String.format("Time: %.3f", time));
			totalAnimalsLabel.setText("Total Animals: " + totalAnimals);
			if (map != null) {
				dimensionLabel.setText(String.format("Dimension: %dx%d (%dx%d)", 
						map.getWidth(), map.getHeight(), map.getCols(), map.getRows()));
			}
		});
	}

	@Override
	public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) {
		updateInfo(time, map, animals.size());
	}

	@Override
	public void onReset(double time, MapInfo map, List<AnimalInfo> animals) {
		updateInfo(time, map, animals.size());
	}

	@Override
	public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) {
		updateInfo(time, map, animals.size());
	}

	@Override
	public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) {
		// No es necesario actualizar nada específico aquí a menos que quieras
	}

	@Override
	public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) {
		updateInfo(time, map, animals.size());
	}
}