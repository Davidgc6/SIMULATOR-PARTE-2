package simulator.factories;

import org.json.JSONObject;
import simulator.model.regions.Region;
import simulator.model.regions.DefaultRegion; 

public class DefaultRegionBuilder extends Builder<Region> {

	public DefaultRegionBuilder() {
		super("default", "Infinite food supply region");
	}

	@Override
	protected Region createInstance(JSONObject data) {
		return new DefaultRegion();
	}
	
	@Override
	protected void fillInData(JSONObject data) {}
}