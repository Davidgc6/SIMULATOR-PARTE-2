package simulator.factories;

import org.json.JSONObject;
import simulator.model.regions.Region;
import simulator.model.regions.DynamicSupplyRegion;

public class DynamicSupplyRegionBuilder extends Builder<Region> {

	public DynamicSupplyRegionBuilder() {
		super("dynamic", "Dynamic food supply region");
	}

	@Override
	protected Region createInstance(JSONObject data) {
		double factor = data.has("factor") ? data.getDouble("factor") : 2.0;
		double food = data.has("food") ? data.getDouble("food") : 100.0;
		
		return new DynamicSupplyRegion(food, factor); 
	}
	
	@Override
	protected void fillInData(JSONObject data) {
		data.put("factor", "food increase factor (optional, default 2.0)");
		data.put("food", "initial amount of food (optional, default 100.0)"); 
	}
}