package simulator.factories;

import org.json.JSONObject;
import simulator.model.SelectionStrategy;
import simulator.model.SelectYoungest;

public class SelectYoungestBuilder extends Builder<SelectionStrategy> {

	public SelectYoungestBuilder() {
		super("youngest", "Selects the youngest animal in the list");
	}

	@Override
	protected SelectionStrategy createInstance(JSONObject data) {
		return new SelectYoungest();
	}
}