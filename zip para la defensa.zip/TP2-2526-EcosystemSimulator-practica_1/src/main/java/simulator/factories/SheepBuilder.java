package simulator.factories;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.SelectionStrategy;
import simulator.model.animals.Animal;
import simulator.model.animals.Sheep;

public class SheepBuilder extends Builder<Animal> {
	private Factory<SelectionStrategy> strategyFactory;

	public SheepBuilder(Factory<SelectionStrategy> strategyFactory) {
		super("sheep", "A sheep");
		this.strategyFactory = strategyFactory;
	}

	@Override
	protected Animal createInstance(JSONObject data) {
		// Por defecto usamos SelectFirst si no lo lee en el JSON
		JSONObject defaultStrategyJSON = new JSONObject().put("type", "first");
		
		SelectionStrategy mateStrategy = data.has("mate_strategy") ? 
				strategyFactory.createInstance(data.getJSONObject("mate_strategy")) : 
				strategyFactory.createInstance(defaultStrategyJSON);
				
		SelectionStrategy dangerStrategy = data.has("danger_strategy") ? 
				strategyFactory.createInstance(data.getJSONObject("danger_strategy")) : 
				strategyFactory.createInstance(defaultStrategyJSON);

		Vector2D pos = null;
		if (data.has("pos")) {
			JSONObject p = data.getJSONObject("pos");
			JSONArray xRange = p.getJSONArray("x_range");
			JSONArray yRange = p.getJSONArray("y_range");
			
			double x = xRange.getDouble(0) + simulator.misc.Utils.RAND.nextDouble() * (xRange.getDouble(1) - xRange.getDouble(0));
			double y = yRange.getDouble(0) + simulator.misc.Utils.RAND.nextDouble() * (yRange.getDouble(1) - yRange.getDouble(0));			
			pos = new Vector2D(x, y);
		}

		return new Sheep(mateStrategy, dangerStrategy, pos);
	}
}