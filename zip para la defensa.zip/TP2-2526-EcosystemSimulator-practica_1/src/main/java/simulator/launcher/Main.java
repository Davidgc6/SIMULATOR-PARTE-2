package simulator.launcher;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import javax.swing.SwingUtilities; // NUEVO: Necesario para arrancar la ventana

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.json.JSONObject;
import org.json.JSONTokener;

import simulator.control.Controller;
import simulator.factories.*;
import simulator.misc.Utils;
import simulator.model.SelectionStrategy;
import simulator.model.Simulator;
import simulator.model.animals.Animal;
import simulator.model.regions.Region;
import simulator.view.MainWindow; // NUEVO: Para poder abrir tu ventana

public class Main {

	private static double time = 10.0;
	public static double deltaTime = 0.03;
	private static boolean simpleViewer = false;
	private static String inFile = null;
	private static String outFile = null;
	private static String mode = "gui";

	public static Factory<SelectionStrategy> strategyFactory;
	public static Factory<Animal> animalFactory;
	public static Factory<Region> regionFactory;

	public static void main(String[] args) {
		Utils.RAND.setSeed(2147483647l);
		try {
			// 1. Procesar los argumentos de la línea de comandos
			parseArgs(args);
			
			// 2. Inicializar las factorías
			initFactories();
			
			// 3. Arrancar la simulación según el modo seleccionado 
			if (mode.equalsIgnoreCase("batch")) {
				startBatchMode();
			} else {
				startGUIMode();
			}
			
		} catch (Exception e) {
			System.err.println("Error crítico en la ejecución: " + e.getMessage());
			e.printStackTrace();
		}
	}

	private static void initFactories() {
		// Inicializar la factoría de estrategias
		List<Builder<SelectionStrategy>> selectionStrategyBuilders = new ArrayList<>();
		selectionStrategyBuilders.add(new SelectFirstBuilder());
		selectionStrategyBuilders.add(new SelectClosestBuilder());
		selectionStrategyBuilders.add(new SelectYoungestBuilder());
		strategyFactory = new BuilderBasedFactory<>(selectionStrategyBuilders);

		// Inicializar la factoría de animales
		List<Builder<Animal>> animalBuilders = new ArrayList<>();
		animalBuilders.add(new SheepBuilder(strategyFactory));
		animalBuilders.add(new WolfBuilder(strategyFactory));
		animalFactory = new BuilderBasedFactory<>(animalBuilders);

		// Inicializar la factoría de regiones
		List<Builder<Region>> regionBuilders = new ArrayList<>();
		regionBuilders.add(new DefaultRegionBuilder());
		regionBuilders.add(new DynamicSupplyRegionBuilder());
		regionFactory = new BuilderBasedFactory<>(regionBuilders);
	}

	private static void startBatchMode() throws Exception {
		// El archivo de entrada y salida son obligatorios
		if (inFile == null) {
			throw new Exception("El archivo de entrada es obligatorio (-i) en modo batch. Usa -h para ayuda.");
		}
		if (outFile == null) { 
			throw new Exception("El archivo de salida es obligatorio (-o) en modo batch. Usa -h para ayuda.");
		}

		// Abrir el archivo de entrada y crear el JSONObject
		InputStream is = new FileInputStream(inFile);
		JSONObject jsonInput = new JSONObject(new JSONTokener(is));

		// Leer las dimensiones del mapa
		int cols = jsonInput.getInt("cols");
		int rows = jsonInput.getInt("rows");
		int width = jsonInput.getInt("width");
		int height = jsonInput.getInt("height");

		// Crear el Simulador y el Controlador
		Simulator sim = new Simulator(cols, rows, width, height, animalFactory, regionFactory);
		Controller controller = new Controller(sim);
		
		// Cargar los datos
		controller.loadData(jsonInput);

		// Preparar la salida
		OutputStream os = new FileOutputStream(outFile);
		
		// Ejecutar la simulación
		controller.run(time, deltaTime, simpleViewer, os);
		
		// Cerrar los flujos de datos
		os.close();
		System.out.println("Simulación completada. Resultado guardado en: " + outFile);
		is.close();
	}

	private static void startGUIMode() throws Exception {
		Simulator sim;
		Controller controller;

		if (inFile != null) {
			InputStream is = new FileInputStream(inFile);
			JSONObject jsonInput = new JSONObject(new JSONTokener(is));
			
			int cols = jsonInput.getInt("cols");
			int rows = jsonInput.getInt("rows");
			int width = jsonInput.getInt("width");
			int height = jsonInput.getInt("height");

			sim = new Simulator(cols, rows, width, height, animalFactory, regionFactory);
			controller = new Controller(sim);
			controller.loadData(jsonInput);
			is.close();
		} 
		else {
			sim = new Simulator(20, 15, 800, 600, animalFactory, regionFactory);
			controller = new Controller(sim);
		}

		SwingUtilities.invokeAndWait(() -> new MainWindow(controller));
	}

	private static void parseArgs(String[] args) throws ParseException {
		Options cmdLineOptions = new Options();

		cmdLineOptions.addOption(Option.builder("h").longOpt("help")
				.desc("Print this message.")
				.build());

		cmdLineOptions.addOption(Option.builder("m").longOpt("mode").hasArg()
				.desc("Execution Mode. Possible values: 'batch' (Batch mode), 'gui' (Graphical User Interface mode). Default value: 'gui'.")
				.build());

		cmdLineOptions.addOption(Option.builder("i").longOpt("input").hasArg()
				.desc("A configuration file (optional in GUI mode).")
				.build());

		cmdLineOptions.addOption(Option.builder("o").longOpt("output").hasArg()
				.desc("A file where output is written (only for BATCH mode).")
				.build());

		cmdLineOptions.addOption(Option.builder("t").longOpt("time").hasArg()
				.desc("An real number representing the total simulation time in seconds. Default value: 10.0. (only for BATCH mode).")
				.build());

		cmdLineOptions.addOption(Option.builder("dt").longOpt("delta-time").hasArg()
				.desc("A real number representing actual time, in seconds, per simulation step. Default value: 0.03.")
				.build());

		cmdLineOptions.addOption(Option.builder("sv").longOpt("simple-viewer")
				.desc("Show the viewer window in BATCH mode.")
				.build());

		CommandLineParser parser = new DefaultParser();
		CommandLine line = parser.parse(cmdLineOptions, args);

		if (line.hasOption("h")) {
			HelpFormatter formatter = new HelpFormatter();
			formatter.printHelp("simulator.launcher.Main", cmdLineOptions);
			System.exit(0);
		}

		if (line.hasOption("m")) {
			mode = line.getOptionValue("m");
		}

		if (line.hasOption("i")) {
			inFile = line.getOptionValue("i");
		}

		if (line.hasOption("o")) {
			outFile = line.getOptionValue("o");
		}

		if (line.hasOption("t")) {
			time = Double.parseDouble(line.getOptionValue("t"));
		}

		if (line.hasOption("dt")) {
			deltaTime = Double.parseDouble(line.getOptionValue("dt"));
		}

		if (line.hasOption("sv")) {
			simpleViewer = true;
		}
	}
}