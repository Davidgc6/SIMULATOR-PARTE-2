package simulator.misc;

public enum Diet {
	HERBIVORE("Herbivoro"), CARNIVORE("Carnivoro");

	private String diet;
	
	private Diet(String diet) {
		this.diet = diet;
	} 
	
	public String getDiet() {
		return this.diet;
	}

	
}
