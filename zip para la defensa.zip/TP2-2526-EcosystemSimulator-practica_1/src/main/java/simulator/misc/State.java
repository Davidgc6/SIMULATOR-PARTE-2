package simulator.misc;

public enum State {
	NORMAL("normal"), MATE("emparejamiento"), HUNGER("hambriento"), DANGER("peligro"), DEAD("muerto");
	
	private String state;
	
	private State(String state) {
		this.state = state;
	}
	
	public String getState() {
		return this.state;
	}
	
}
