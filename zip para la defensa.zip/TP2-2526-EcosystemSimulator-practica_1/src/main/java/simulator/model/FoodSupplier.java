package simulator.model;

import simulator.model.animals.AnimalInfo;

public interface FoodSupplier {
	double getfood(AnimalInfo a, double dt);
}