package simulator.model;

import java.util.List;
import simulator.model.animals.Animal;

public class SelectClosest implements SelectionStrategy {

	@Override
	public Animal select(Animal a, List<Animal> as) {
		if (as == null || as.isEmpty()) {
			return null;
		}
		
		Animal closest = as.get(0);
		double minDistance = a.getPosition().distanceTo(closest.getPosition());
		
		for(Animal e : as) {
			double currentDistance = a.getPosition().distanceTo(e.getPosition());
			if(currentDistance < minDistance) {
				closest = e;
				minDistance = currentDistance; 
			}
		}
		return closest;
	}

}