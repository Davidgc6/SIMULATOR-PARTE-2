package simulator.model;

import java.util.List;
import simulator.model.animals.Animal;

public class SelectYoungest implements SelectionStrategy {

	@Override
	public Animal select(Animal a, List<Animal> as) {
		if (as == null || as.isEmpty()) {
			return null;
		}
		
		Animal youngest = as.get(0);
		for(Animal e : as) {
			if(e.getAge() < youngest.getAge()) { 
				youngest = e;
			}
		}
		return youngest;
	}

}