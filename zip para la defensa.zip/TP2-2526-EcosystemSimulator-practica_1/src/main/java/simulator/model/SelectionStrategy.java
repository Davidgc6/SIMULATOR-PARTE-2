package simulator.model;

import java.util.List;

import simulator.model.animals.Animal;

public interface SelectionStrategy {
	Animal select(Animal a, List<Animal> as);
	
}