package simulator.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.json.JSONObject;

import simulator.factories.Factory;
import simulator.model.animals.Animal;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.Region;
import simulator.model.regions.RegionManager;
import simulator.misc.State;

public class Simulator implements JSONable, Observable<EcoSysObserver> {
	
	private Factory<Animal> animalsFactory;
	private Factory<Region> regionsFactory;
	private List<Animal> animalsInSimulation;
	private RegionManager regionMngr;
	private double actualTime;
	private List<EcoSysObserver> observers; 
	
	public Simulator(int cols, int rows, int width, int height,
			Factory<Animal> animalsFactory, Factory<Region> regionsFactory) {
		this.regionMngr = new RegionManager(cols, rows, width, height);
		this.animalsFactory = animalsFactory;
		this.regionsFactory = regionsFactory;
		this.animalsInSimulation = new ArrayList<>();
		this.actualTime = 0.0;
		this.observers = new ArrayList<>(); 
	}

	@Override
	public void addObserver(EcoSysObserver o) {
		if (!observers.contains(o)) {
			observers.add(o);
			o.onRegister(actualTime, regionMngr, new ArrayList<>(animalsInSimulation));
		}
	}

	@Override
	public void removeObserver(EcoSysObserver o) {
		observers.remove(o);
	}
	
	public void reset(int cols, int rows, int width, int height) {
		this.animalsInSimulation.clear();
		this.regionMngr = new RegionManager(cols, rows, width, height);
		this.actualTime = 0.0;
		
		for (EcoSysObserver o : observers) {
			o.onReset(actualTime, regionMngr, new ArrayList<>(animalsInSimulation));
		}
	}
	
	private void setRegion(int row, int col, Region r) {
		this.regionMngr.setRegion(row, col, r);
		
		for (EcoSysObserver o : observers) {
			o.onRegionSet(row, col, regionMngr, r);
		}
	}
	
	public void setRegion(int row, int col, JSONObject rJson) {
		Region r = regionsFactory.createInstance(rJson);
		this.setRegion(row, col, r);
	}
	
	private void addAnimal(Animal a) {
		this.animalsInSimulation.add(a);
		this.regionMngr.registerAnimal(a);
		
		for (EcoSysObserver o : observers) {
			o.onAnimalAdded(actualTime, regionMngr, new ArrayList<>(animalsInSimulation), a);
		}
	}
	
	public void addAnimal(JSONObject aJson) {
		Animal animalFromJSON = animalsFactory.createInstance(aJson);
		this.addAnimal(animalFromJSON);
	}
	
	public MapInfo getMapInfo() {
		return this.regionMngr;
	}
	
	public List<? extends AnimalInfo> getAnimals(){
		return Collections.unmodifiableList(this.animalsInSimulation);
	}
	
	public double getTime() {
		return actualTime;
	}
	
	public void advance(double dt) {
		this.actualTime += dt;
		
		animalsInSimulation.removeIf(a -> a.getState() == State.DEAD);
		
		for (Animal a : animalsInSimulation) {
			a.update(dt);
		}
		
		regionMngr.update(dt);
		
		List<Animal> babies = new ArrayList<>();
		for (Animal a : animalsInSimulation) {
			Animal baby = a.deliverBaby();
			if (baby != null) {
				babies.add(baby);
			}
		}
		
		for (Animal baby : babies) {
			addAnimal(baby); 
		}

		for (EcoSysObserver o : observers) {
			o.onAdvance(actualTime, regionMngr, new ArrayList<>(animalsInSimulation), dt);
		}
	}
	
	public JSONObject asJSON() {
		JSONObject out = new JSONObject();
		out.put("time", actualTime);
		out.put("state", regionMngr.asJSON()); 
		return out;
	}
}