package simulator.model.animals;

import org.json.JSONObject;

import simulator.misc.Diet;
import simulator.misc.State;
import simulator.misc.Utils;
import simulator.misc.Vector2D;
import simulator.model.AnimalMapView;
import simulator.model.Entity;
import simulator.model.SelectionStrategy;

public abstract class Animal implements AnimalInfo, Entity {
	
	protected String geneticCode;
	protected Diet diet;
	protected State state;
	protected Vector2D pos;
	protected Vector2D dest;
	protected double energy, speed, age, desire, sightRange;
	protected Animal mateTarget, baby;
	protected AnimalMapView regionMngr;
	protected SelectionStrategy mateStrategy;
	
	protected Animal(String geneticCode, Diet diet, double sightRange, double initSpeed, SelectionStrategy mateStrategy, Vector2D pos) throws IllegalArgumentException {
		if(geneticCode == null || geneticCode.length() == 0 || sightRange <= 0 || initSpeed <= 0 || mateStrategy == null) {
			throw new IllegalArgumentException("Hay datos inválidos");
		}
		
		this.geneticCode = geneticCode;
		this.diet = diet;		
		this.sightRange = sightRange;
		this.mateStrategy = mateStrategy;
		this.pos = pos;
		
		this.regionMngr = null;
		this.state = State.NORMAL;
		this.desire = 0.0;
		this.age = 0.0; 
		
		this.speed = Utils.getRandomizedParameter(initSpeed, 0.1);
	}
	
	protected Animal(Animal p1, Animal p2) {
		this.dest = null;
		this.baby = null;
		this.mateTarget = null;
		this.regionMngr = null;
		this.state = State.NORMAL;
		this.desire = 0.0;
		this.age = 0.0; 
		
		this.geneticCode = p1.getGeneticCode();
		this.diet = p1.getDiet();
		this.mateStrategy = p2.mateStrategy;
		this.energy = (p1.getEnergy() + p2.getEnergy()) / 2.0;
		
		this.pos = p1.getPosition().plus(Vector2D.get_random_vector(-1,1).scale(60.0 * (Utils.RAND.nextGaussian() + 1)));
		this.sightRange = Utils.getRandomizedParameter((p1.getSightRange() + p2.getSightRange()) / 2.0, 0.2);
		this.speed = Utils.getRandomizedParameter((p1.getSpeed() + p2.getSpeed()) / 2.0, 0.2);
	}
	
	public void init(AnimalMapView regMngr) {
		this.regionMngr = regMngr;
		if(this.pos == null) {
			Vector2D usableVectorPosX = Vector2D.get_random_vector(0, regionMngr.getWidth());
			Vector2D usableVectorPosY = Vector2D.get_random_vector(0, regionMngr.getHeight());
			this.pos = new Vector2D(usableVectorPosX.getX(), usableVectorPosY.getY());
		}
		
		Vector2D usableVectorDestX = Vector2D.get_random_vector(0, regionMngr.getWidth());
		Vector2D usableVectorDestY = Vector2D.get_random_vector(0, regionMngr.getHeight());
		this.dest = new Vector2D(usableVectorDestX.getX(), usableVectorDestY.getY());
	}
	
	public Animal deliverBaby() {
		Animal babyToReturn = this.baby;
		this.baby = null;
		return babyToReturn;
	}
	
	protected void move(double speed) {
		if (pos != null && dest != null) {
			pos = pos.plus(dest.minus(pos).direction().scale(speed));
		}
	}
	
	protected void setState(State state) {
		this.state = state;
		switch (state) {
		case NORMAL:
			setNormalStateAction();
			break;
		case HUNGER:
			setHungerStateAction();
			break; 
		case MATE:
			setMateStateAction();
			break;
		case DANGER:
			setDangerStateAction();
			break;
		case DEAD:
			setDeadStateAction();
			break;
		}
	}
	
	public JSONObject asJSON() {
		JSONObject animalJSON = new JSONObject();
		animalJSON.put("pos", getPosition().asJSONArray());
		animalJSON.put("gcode", getGeneticCode());
		animalJSON.put("state", getState().toString());
		animalJSON.put("diet", getDiet().toString());
		return animalJSON;
	}

	@Override
	public State getState() { return state; }

	@Override
	public Vector2D getPosition() { return pos; }

	@Override
	public String getGeneticCode() { return geneticCode; }

	@Override
	public Diet getDiet() { return diet; }

	@Override
	public double getSpeed() { return speed; }

	@Override
	public double getSightRange() { return sightRange; }

	@Override
	public double getEnergy() { return energy; } 

	@Override
	public double getAge() { return age; } 

	@Override
	public Vector2D getDestination() { return dest; }

	@Override
	public boolean isPregnant() { return (baby != null); }

	protected abstract void setDeadStateAction();
	protected abstract void setDangerStateAction();
	protected abstract void setMateStateAction();
	protected abstract void setHungerStateAction();
	protected abstract void setNormalStateAction();
}