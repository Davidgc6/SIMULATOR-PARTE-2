package simulator.model.animals;

import java.util.List;
import simulator.misc.Constantes;
import simulator.misc.Diet;
import simulator.misc.State;
import simulator.misc.Vector2D;
import simulator.misc.Utils;
import simulator.model.SelectionStrategy;

public class Sheep extends Animal {

	protected Animal dangerSource;
	protected SelectionStrategy dangerStrategy;

	public Sheep(SelectionStrategy mateStrategy, SelectionStrategy dangerStrategy, Vector2D pos) {
		super(Constantes.SHEEP_GENETIC_CODE, Diet.HERBIVORE, Constantes.INIT_SIGHT_SHEEP, Constantes.INIT_SPEED_SHEEP, mateStrategy, pos);
		this.dangerStrategy = dangerStrategy;
		this.dangerSource = null;
		this.state = State.NORMAL;
		this.energy = Constantes.MAX_ENERGY;
		this.desire = 0.0;
	}

	protected Sheep(Sheep p1, Animal p2) {
		super(p1, p2);
		this.dangerStrategy = p1.dangerStrategy;
		this.dangerSource = null;
	}

	@Override
	public void update(double dt) {
		if (this.state == State.DEAD) return;

		switch (this.state) {
			case NORMAL: updateNormal(dt); break;
			case DANGER: updateDanger(dt); break;
			case MATE:   updateMate(dt);   break;
			default: break;
		}

		if (regionMngr != null && (pos.getX() < 0 || pos.getX() >= regionMngr.getWidth() || 
			pos.getY() < 0 || pos.getY() >= regionMngr.getHeight())) {
			
			double x = Math.max(0, Math.min(pos.getX(), regionMngr.getWidth() - 0.1));
			double y = Math.max(0, Math.min(pos.getY(), regionMngr.getHeight() - 0.1));
			this.pos = new Vector2D(x, y);
			setState(State.NORMAL); 
		}

		if (this.energy <= 0.0 || this.age > Constantes.MAX_AGE_SHEEP) {
			setState(State.DEAD);
		}

		if (this.state != State.DEAD && regionMngr != null) {
			this.energy = Math.min(Constantes.MAX_ENERGY, this.energy + regionMngr.getfood(this, dt));
		}
	}

	private void updateNormal(double dt) {
		if (regionMngr != null && this.pos.distanceTo(this.dest) < Constantes.COLLISION_RANGE) {
			this.dest = new Vector2D(Utils.RAND.nextDouble() * regionMngr.getWidth(), 
									 Utils.RAND.nextDouble() * regionMngr.getHeight());
		}

		move(this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));
		
		this.age += dt;
		this.energy = Math.max(0.0, this.energy - Constantes.FOOD_DROP_RATE_SHEEP * dt);
		this.desire = Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_SHEEP * dt);

		if (dangerSource == null) {
			findDanger();
		}

		if (dangerSource != null) {
			setState(State.DANGER);
		} else if (this.desire > Constantes.DESIRE_THRESHOLD_SHEEP) {
			setState(State.MATE);
		}
	}

	private void updateDanger(double dt) {
		if (dangerSource != null && dangerSource.getState() == State.DEAD) {
			dangerSource = null;
		}

		if (dangerSource == null) {
			updateNormal(dt);
		} else {
			this.dest = this.pos.plus(this.pos.minus(dangerSource.getPosition()).direction());
			move(Constantes.BOOST_FACTOR_SHEEP * this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));

			this.age += dt;
			this.energy = Math.max(0.0, this.energy - Constantes.FOOD_DROP_RATE_SHEEP * Constantes.FOOD_DROP_BOOST_FACTOR_SHEEP * dt);
			this.desire = Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_SHEEP * dt);
		}

		if (dangerSource == null || this.pos.distanceTo(dangerSource.getPosition()) > this.sightRange) {
			findDanger();
			if (dangerSource == null) {
				if (this.desire < Constantes.DESIRE_THRESHOLD_SHEEP) setState(State.NORMAL);
				else setState(State.MATE);
			}
		}
	}

	private void updateMate(double dt) {
		if (mateTarget != null && (mateTarget.getState() == State.DEAD || this.pos.distanceTo(mateTarget.getPosition()) > this.sightRange)) {
			mateTarget = null;
		}

		if (mateTarget == null) {
			findMate();
			if (mateTarget == null) updateNormal(dt);
		}

		if (mateTarget != null) {
			this.dest = mateTarget.getPosition();
			move(Constantes.BOOST_FACTOR_SHEEP * this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));

			this.age += dt;
			this.energy = Math.max(0.0, this.energy - Constantes.FOOD_DROP_RATE_SHEEP * Constantes.FOOD_DROP_BOOST_FACTOR_SHEEP * dt);
			this.desire = Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_SHEEP * dt);

			if (this.pos.distanceTo(mateTarget.getPosition()) < Constantes.COLLISION_RANGE) {
				this.desire = 0.0;
				mateTarget.desire = 0.0; 
				if (this.baby == null && Utils.RAND.nextDouble() < Constantes.PREGNANT_PROBABILITY_SHEEP) {
					this.baby = new Sheep(this, mateTarget);
				}
				mateTarget = null;
				
				findDanger();
				if (dangerSource != null) setState(State.DANGER);
				else if (this.desire < Constantes.DESIRE_THRESHOLD_SHEEP) setState(State.NORMAL);
			}
		}
	}

	private void findDanger() {
		if (regionMngr != null) {
			List<Animal> potentialDangers = regionMngr.getAnimalsInRange(this, a -> a.getDiet() == Diet.CARNIVORE && a.getState() != State.DEAD);
			this.dangerSource = dangerStrategy.select(this, potentialDangers);
		}
	}

	private void findMate() {
		if (regionMngr != null) {
			List<Animal> potentialMates = regionMngr.getAnimalsInRange(this, a -> a.getGeneticCode().equals(this.getGeneticCode()) && a != this && a.getState() != State.DEAD);
			this.mateTarget = mateStrategy.select(this, potentialMates);
		}
	}

	@Override
	protected void setNormalStateAction() {
		this.dangerSource = null;
		this.mateTarget = null;
	}

	@Override
	protected void setMateStateAction() {
		this.dangerSource = null;
	}

	@Override
	protected void setDangerStateAction() {
		this.mateTarget = null;
	}

	@Override protected void setDeadStateAction() { } 
	@Override protected void setHungerStateAction() { }
}