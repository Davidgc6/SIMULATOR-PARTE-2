package simulator.model.animals;

import simulator.misc.Constantes;
import simulator.misc.Diet;
import simulator.misc.State;
import simulator.misc.Vector2D;
import simulator.misc.Utils;
import simulator.model.SelectionStrategy;

public class Wolf extends Animal {

	protected Animal huntTarget;
	protected SelectionStrategy huntingStrategy;

	public Wolf(SelectionStrategy mateStrategy, SelectionStrategy huntingStrategy, Vector2D pos) {
		super(Constantes.WOLF_GENETIC_CODE, Diet.CARNIVORE, Constantes.INIT_SIGHT_WOLF, Constantes.INIT_SPEED_WOLF, mateStrategy, pos);
		this.huntingStrategy = huntingStrategy;
		this.huntTarget = null;
		this.state = State.NORMAL; 
		this.energy = Constantes.MAX_ENERGY;
		this.desire = 0.0;
	}

	protected Wolf(Wolf p1, Animal p2) {
		super(p1, p2);
		this.huntingStrategy = p1.huntingStrategy;
		this.huntTarget = null;
	}

	@Override
	public void update(double dt) {
		if (this.state == State.DEAD) return;
		
		switch (this.state) {
			case NORMAL: updateNormal(dt); break;
			case HUNGER: updateHunger(dt); break;
			case MATE:   updateMate(dt);   break;
			default: break; 
		}

		if (this.pos.getX() < 0 || this.pos.getX() >= regionMngr.getWidth() || 
			this.pos.getY() < 0 || this.pos.getY() >= regionMngr.getHeight()) {
			
			double x = Math.max(0, Math.min(this.pos.getX(), regionMngr.getWidth() - 0.1));
			double y = Math.max(0, Math.min(this.pos.getY(), regionMngr.getHeight() - 0.1));
			this.pos = new Vector2D(x, y);
			setState(State.NORMAL);
		}

		if (this.energy <= 0.0 || this.age > Constantes.MAX_AGE_WOLF) {
			setState(State.DEAD);
		}

		if (this.state != State.DEAD) {
			this.energy += regionMngr.getfood(this, dt); 
			if (this.energy > Constantes.MAX_ENERGY) this.energy = Constantes.MAX_ENERGY;
		}
	}

	private void updateNormal(double dt) {
		if (this.pos.distanceTo(this.dest) < Constantes.COLLISION_RANGE) {
			this.dest = new Vector2D(Utils.RAND.nextDouble() * regionMngr.getWidth(), 
									 Utils.RAND.nextDouble() * regionMngr.getHeight());
		}
		
		move(this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));
		
		this.age += dt;
		this.energy = Math.max(0.0, Math.min(Constantes.MAX_ENERGY, this.energy - Constantes.FOOD_DROP_RATE_WOLF * dt));
		this.desire = Math.max(0.0, Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_WOLF * dt));

		if (this.energy < Constantes.FOOD_THRSHOLD_WOLF) {
			setState(State.HUNGER);
		} else if (this.desire > Constantes.DESIRE_THRESHOLD_WOLF) {
			setState(State.MATE);
		}
	}

	private void updateHunger(double dt) {
		if (huntTarget == null || huntTarget.getState() == State.DEAD || this.pos.distanceTo(huntTarget.getPosition()) > this.sightRange) {
			huntTarget = huntingStrategy.select(this, regionMngr.getAnimalsInRange(this, a -> a.getDiet() == Diet.HERBIVORE && a.getState() != State.DEAD));
		}

		if (huntTarget == null) {
			updateNormal(dt); 
		} else {
			this.dest = huntTarget.getPosition();
			move(Constantes.BOOST_FACTOR_WOLF * this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));
			
			this.age += dt;
			this.energy = Math.max(0.0, Math.min(Constantes.MAX_ENERGY, this.energy - Constantes.FOOD_DROP_RATE_WOLF * Constantes.FOOD_DROP_BOOST_FACTOR_WOLF * dt));
			this.desire = Math.max(0.0, Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_WOLF * dt));

			if (this.pos.distanceTo(huntTarget.getPosition()) < Constantes.COLLISION_RANGE) {
				huntTarget.setState(State.DEAD); 
				huntTarget = null;
				this.energy = Math.min(Constantes.MAX_ENERGY, this.energy + Constantes.FOOD_EAT_VALUE_WOLF);
				
				if (this.energy > Constantes.FOOD_THRSHOLD_WOLF) {
					if (this.desire < Constantes.DESIRE_THRESHOLD_WOLF) setState(State.NORMAL);
					else setState(State.MATE);
				}
			}
		}
	}

	private void updateMate(double dt) {
		if (mateTarget != null && (mateTarget.getState() == State.DEAD || this.pos.distanceTo(mateTarget.getPosition()) > this.sightRange)) {
			mateTarget = null;
		}

		if (mateTarget == null) {
			mateTarget = mateStrategy.select(this, regionMngr.getAnimalsInRange(this, a -> a.getGeneticCode().equals(this.getGeneticCode()) && a != this && a.getState() != State.DEAD));
		}

		if (mateTarget == null) {
			updateNormal(dt);
		} else {
			this.dest = mateTarget.getPosition();
			move(Constantes.BOOST_FACTOR_WOLF * this.speed * dt * Math.exp((this.energy - Constantes.MAX_ENERGY) * Constantes.HUNGER_DECAY_EXP_FACTOR));
			
			this.age += dt;
			this.energy = Math.max(0.0, Math.min(Constantes.MAX_ENERGY, this.energy - Constantes.FOOD_DROP_RATE_WOLF * Constantes.FOOD_DROP_BOOST_FACTOR_WOLF * dt));
			this.desire = Math.max(0.0, Math.min(Constantes.MAX_DESIRE, this.desire + Constantes.DESIRE_INCREASE_RATE_WOLF * dt));

			if (this.pos.distanceTo(mateTarget.getPosition()) < Constantes.COLLISION_RANGE) {
				this.desire = 0.0;
				mateTarget.desire = 0.0; 
				
				if (this.baby == null && Utils.RAND.nextDouble() < Constantes.PREGNANT_PROBABILITY_WOLF) {
					this.baby = new Wolf(this, mateTarget);
				}
				
				this.energy = Math.max(0.0, this.energy - Constantes.FOOD_DROP_DESIRE_WOLF);
				mateTarget = null;
				
				if (this.energy < Constantes.FOOD_THRSHOLD_WOLF) setState(State.HUNGER);
				else if (this.desire < Constantes.DESIRE_THRESHOLD_WOLF) setState(State.NORMAL);
			}
		}
	}

	@Override
	protected void setNormalStateAction() {
		this.huntTarget = null;
		this.mateTarget = null;
	}

	@Override
	protected void setMateStateAction() {
		this.huntTarget = null;
	}

	@Override
	protected void setHungerStateAction() {
		this.mateTarget = null;
	}

	@Override protected void setDeadStateAction() { } 
	@Override protected void setDangerStateAction() { }
}