package simulator.model.regions;

import simulator.misc.Diet;
import simulator.model.animals.AnimalInfo;

public class DefaultRegion extends Region {

	@Override
	public double getfood(AnimalInfo a, double dt) {
		if (a.getDiet() == Diet.CARNIVORE) {
			return 0.0;
		}
		
		int n = herbivoresInRegion();
		return (60.0 * Math.exp(-Math.max(0, n - 5.0) * 2.0) * dt);
	}

	@Override
	public void update(double dt) {}
	
	@Override
	public String toString() {
		return "Default region"; 
	}
}