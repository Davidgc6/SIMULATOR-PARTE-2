package simulator.model.regions;

import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;
import simulator.misc.Diet;
import simulator.misc.State;
import simulator.model.Entity;
import simulator.model.FoodSupplier;
import simulator.model.animals.Animal;
import simulator.model.animals.AnimalInfo;

public abstract class Region implements Entity, FoodSupplier, RegionInfo {
	
	protected List<Animal> animalListInRegion;
	
	public Region() {
		this.animalListInRegion = new ArrayList<>();
	}

	final void addAnimal(Animal a) {
		animalListInRegion.add(a);
	}
	
	final void removeAnimal(Animal a) {
		animalListInRegion.remove(a);
	}
	
	final List<Animal> getAnimals() {
		return this.animalListInRegion;
	}
	
	@Override
	public JSONObject asJSON() {
		JSONObject regionJSON = new JSONObject();
		JSONArray animalsArray = new JSONArray();
		
		for(Animal a : animalListInRegion) {
			animalsArray.put(a.asJSON());
		}
		
		regionJSON.put("animals", animalsArray);
		return regionJSON;
	}
	
	protected int herbivoresInRegion() {
		int herbivores = 0;
		for(Animal a : this.animalListInRegion) {
			if(a.getDiet() == Diet.HERBIVORE && a.getState() != State.DEAD) {
				herbivores++;
			}
		}
		return herbivores;
	}
	
	@Override
	public List<AnimalInfo> getAnimalsInfo() {
		return new ArrayList<>(this.animalListInRegion);
	}
}