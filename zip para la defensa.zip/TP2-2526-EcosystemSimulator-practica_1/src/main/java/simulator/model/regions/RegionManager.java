package simulator.model.regions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import org.json.JSONArray;
import org.json.JSONObject;

import simulator.misc.Vector2D;
import simulator.model.AnimalMapView;
import simulator.model.animals.Animal;
import simulator.model.animals.AnimalInfo;

import java.util.Iterator;
import java.util.NoSuchElementException;
import simulator.model.MapInfo;

public class RegionManager implements AnimalMapView {
	
	private int cols, rows, width, height, regionWidth, regionHeight;
	private Region[][] regions;
	private Map<Animal, Region> animalRegion;
	
	public RegionManager(int cols, int rows, int width, int height) {
		this.cols = cols;
		this.rows = rows;
		this.width = width;
		this.height = height;
		this.regionWidth = width / cols;
		this.regionHeight = height / rows;
		
		this.regions = new Region[rows][cols];
		this.animalRegion = new HashMap<>();
		
		for(int i = 0; i < rows; i++) {
			for(int j = 0; j < cols; j++) {
				this.regions[i][j] = new DefaultRegion();
			}
		}
	}

	public void updateanimalRegion(Animal a) {
		Region currentReg = animalRegion.get(a);
		Region newReg = findRegionByPosition(a.getPosition());
		
		if (currentReg == null || !currentReg.equals(newReg)) {
			if (currentReg != null) {
				currentReg.removeAnimal(a);
			}
			animalRegion.put(a, newReg);
			newReg.addAnimal(a);
		}
	}
	
	public void setRegion(int row, int col, Region r) {
		Region oldRegion = regions[row][col];
		
		if (oldRegion != null) {
			List<Animal> animalsInOldRegion = new ArrayList<>(oldRegion.getAnimals());
			for(Animal a : animalsInOldRegion) {
				r.addAnimal(a);
				animalRegion.put(a, r); 
			}
		}
		
		regions[row][col] = r;
	}

	public void registerAnimal(Animal a) {
		a.init(this);
		Region reg = findRegionByPosition(a.getPosition());
		animalRegion.put(a, reg);
		reg.addAnimal(a);
	}
	
	public void unregisterAnimal(Animal a) {
		Region reg = animalRegion.get(a);
		if (reg != null) {
			reg.removeAnimal(a);
		}
		animalRegion.remove(a);
	}
	
	private Region findRegionByPosition(Vector2D position) {
		int col = (int) (position.getX() / this.regionWidth);
		int row = (int) (position.getY() / this.regionHeight);
		
		if (col >= cols) col = cols - 1;
		if (col < 0) col = 0;
		if (row >= rows) row = rows - 1;
		if (row < 0) row = 0;
		
		return regions[row][col]; 
	}
	
	@Override
	public double getfood(AnimalInfo a, double dt) {
		Region reg = animalRegion.get((Animal) a);
		if (reg != null) {
			return reg.getfood(a, dt); 
		}
		return 0.0;
	}
	
	public void update(double dt) {
		for(int i = 0; i < this.rows; i++) {
			for(int j = 0; j < this.cols; j++) {
				if (regions[i][j] != null) {
					regions[i][j].update(dt);
				}
			}
		}
		
		List<Animal> animals = new ArrayList<>(animalRegion.keySet());
		for(Animal a : animals) {
			updateanimalRegion(a);
		}
	}

	@Override
	public List<Animal> getAnimalsInRange(Animal e, Predicate<Animal> filter) {
		List<Animal> animalsInRange = new ArrayList<>();
		
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				if (regions[i][j] != null) {
					for (Animal a : regions[i][j].getAnimals()) {
						if (a != e && filter.test(a)) {
							if (e.getPosition().distanceTo(a.getPosition()) <= e.getSightRange()) {
								animalsInRange.add(a);
							}
						}
					}
				}
			}
		}
		return animalsInRange;
	}	
	
	private JSONArray asJSONArray() {
		JSONArray regionsJSONArray = new JSONArray();

		for(int i = 0; i < this.rows; i++) {
			for(int j = 0; j < this.cols; j++) {
				JSONObject objRegion = new JSONObject();
				objRegion.put("row", i);
				objRegion.put("col", j);
				if (regions[i][j] != null) {
					objRegion.put("data", regions[i][j].asJSON());
				}
				regionsJSONArray.put(objRegion);
			}
		}
		return regionsJSONArray;
	}
	
	@Override
	public JSONObject asJSON() {
		JSONObject regionMngrJSON = new JSONObject();
		regionMngrJSON.put("regions", asJSONArray());
		return regionMngrJSON;
	}
	
	@Override
	public Iterator<MapInfo.RegionData> iterator() {
		return new Iterator<MapInfo.RegionData>() {
			private int currentRow = 0;
			private int currentCol = 0;

			@Override
			public boolean hasNext() {
				// Mientras no nos hayamos pasado de la última fila, hay elementos
				return currentRow < rows;
			}

			@Override
			public MapInfo.RegionData next() {
				if (!hasNext()) {
					throw new NoSuchElementException();
				}
				
				// Extraemos los datos de la región actual
				MapInfo.RegionData data = new MapInfo.RegionData(currentRow, currentCol, regions[currentRow][currentCol]);
				
				// Avanzamos a la siguiente columna
				currentCol++;
				
				// Si nos pasamos de las columnas, reseteamos columna y saltamos a la siguiente fila
				if (currentCol >= cols) {
					currentCol = 0;
					currentRow++;
				}
				
				return data;
			}
		};
	}
	
	@Override public int getCols() { return cols; }
	@Override public int getRows() { return rows; }
	@Override public int getWidth() { return width; }
	@Override public int getHeight() { return height; }
	@Override public int getRegionWidth() { return regionWidth; }
	@Override public int getRegionHeight() { return regionHeight; }
}