package simulator.view;

import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

import simulator.control.Controller;
import simulator.misc.Diet;
import simulator.model.EcoSysObserver;
import simulator.model.MapInfo;
import simulator.model.animals.AnimalInfo;
import simulator.model.regions.RegionInfo;

public class RegionsTableModel extends AbstractTableModel implements EcoSysObserver {

	private List<String> columnNames;
	private List<MapInfo.RegionData> regionsData;

	public RegionsTableModel(Controller ctrl) {
		this.columnNames = new ArrayList<>();
		this.regionsData = new ArrayList<>();
		
		// Columnas dinámicas
		this.columnNames.add("Row");
		this.columnNames.add("Col");
		this.columnNames.add("Desc.");
		for (Diet d : Diet.values()) {
			this.columnNames.add(d.toString());
		}
		
		ctrl.addObserver(this);
	}

	@Override
	public int getRowCount() {
		return regionsData.size();
	}

	@Override
	public int getColumnCount() {
		return columnNames.size();
	}
	
	@Override
	public String getColumnName(int column) {
		return columnNames.get(column);
	}

	@Override
	public Object getValueAt(int rowIndex, int columnIndex) {
		MapInfo.RegionData rd = regionsData.get(rowIndex);
		
		if (columnIndex == 0) return rd.row();
		if (columnIndex == 1) return rd.col();
		if (columnIndex == 2) return rd.r().toString();
		
		Diet diet = Diet.values()[columnIndex - 3];
		int count = 0;
		for (AnimalInfo a : rd.r().getAnimalsInfo()) {
			if (a.getDiet() == diet) {
				count++;
			}
		}
		return count;
	}

	private void updateData(MapInfo map) {
		regionsData.clear();
		if (map != null) {
			for (MapInfo.RegionData rd : map) {
				regionsData.add(rd);
			}
		}
		fireTableDataChanged();
	}

	@Override public void onRegister(double time, MapInfo map, List<AnimalInfo> animals) { updateData(map); }
	@Override public void onReset(double time, MapInfo map, List<AnimalInfo> animals) { updateData(map); }
	@Override public void onAnimalAdded(double time, MapInfo map, List<AnimalInfo> animals, AnimalInfo a) { updateData(map); }
	@Override public void onAdvance(double time, MapInfo map, List<AnimalInfo> animals, double dt) { updateData(map); }
	@Override public void onRegionSet(int row, int col, MapInfo map, RegionInfo r) { updateData(map); }
}